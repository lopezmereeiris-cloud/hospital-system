export { default } from "./AppointmentTable";
