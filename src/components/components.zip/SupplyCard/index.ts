export { default } from './SupplyCard';
