export { default } from "./DoctorDetailModal";
