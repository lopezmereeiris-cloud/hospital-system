export { default } from "./AlertIndicator";
