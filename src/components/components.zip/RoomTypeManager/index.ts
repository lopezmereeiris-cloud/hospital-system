export { default } from "./RoomTypeManager";
