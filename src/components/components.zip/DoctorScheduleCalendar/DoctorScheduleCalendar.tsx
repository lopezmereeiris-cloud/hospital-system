"use doctor";

import React, { useMemo } from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Chip from "@mui/material/Chip";
import Typography from "@mui/material/Typography";
import { palette } from "@/theme/palette";

type ScheduleStatus = "Available" | "Booked" | "Unavailable";

export interface DoctorSchedule {
  id: number;
  doctorName: string;
  date: string;
  time: string;
  endTime: string;
  department: string;
  room?: string;
  status: ScheduleStatus;
  notes?: string;
}

interface DoctorScheduleCalendarProps {
  schedules: DoctorSchedule[];
  onEventClick?: (schedule: DoctorSchedule) => void;
}

const WEEK_DAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

const TIME_SLOTS = [
  "08:00 AM",
  "09:00 AM",
  "10:00 AM",
  "11:00 AM",
  "12:00 PM",
  "01:00 PM",
  "02:00 PM",
  "03:00 PM",
  "04:00 PM",
  "05:00 PM",
];

const parseTimeToMinutes = (rawTime: string) => {
  const [time, modifier] = rawTime.trim().split(" ");
  let [hours, minutes] = time.split(":").map(Number);

  if (modifier === "PM" && hours !== 12) hours += 12;
  if (modifier === "AM" && hours === 12) hours = 0;

  return hours * 60 + minutes;
};

const formatDayLabel = (date: Date) =>
  date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
  });

const getWeekStart = (dateStr: string) => {
  const date = new Date(dateStr);
  const day = date.getDay();
  const start = new Date(date);
  start.setDate(date.getDate() - day);
  start.setHours(0, 0, 0, 0);
  return start;
};

const statusStyles: Record<
  ScheduleStatus,
  { bg: string; border: string; text: string }
> = {
  Available: {
    bg: "#ECFDF3",
    border: "#ABEFC6",
    text: "#067647",
  },
  Booked: {
    bg: "#EEF4FF",
    border: "#C7D7FE",
    text: "#1D4ED8",
  },
  Unavailable: {
    bg: "#FEF3F2",
    border: "#FECDCA",
    text: "#D92D20",
  },
};

export default function DoctorScheduleCalendar({
  schedules,
  onEventClick,
}: DoctorScheduleCalendarProps) {
  const weekStart = useMemo(() => {
    if (!schedules.length) return getWeekStart("2026-03-12");
    return getWeekStart(schedules[0].date);
  }, [schedules]);

  const weekDates = useMemo(() => {
    return Array.from({ length: 7 }, (_, index) => {
      const date = new Date(weekStart);
      date.setDate(weekStart.getDate() + index);
      return date;
    });
  }, [weekStart]);

  const groupedSchedules = useMemo(() => {
    const grouped: Record<string, DoctorSchedule[]> = {};

    schedules.forEach((schedule) => {
      if (!grouped[schedule.date]) grouped[schedule.date] = [];
      grouped[schedule.date].push(schedule);
    });

    Object.keys(grouped).forEach((dateKey) => {
      grouped[dateKey].sort(
        (a, b) => parseTimeToMinutes(a.time) - parseTimeToMinutes(b.time)
      );
    });

    return grouped;
  }, [schedules]);

  return (
    <Card
      sx={{
        borderRadius: 1,
        border: `1px solid ${palette.grey[200]}`,
        boxShadow: "none",
        overflow: "hidden",
      }}
    >
      <Box sx={{ overflowX: "auto" }}>
        <Box
          sx={{
            display: "grid",
            gridTemplateColumns: "110px repeat(7, minmax(180px, 1fr))",
            minWidth: "1380px",
          }}
        >
          <Box
            sx={{
              borderRight: `1px solid ${palette.grey[200]}`,
              borderBottom: `1px solid ${palette.grey[200]}`,
              backgroundColor: "grey.50",
            }}
          />

          {weekDates.map((date, index) => (
            <Box
              key={index}
              sx={{
                px: 1.5,
                py: 1.25,
                borderRight:
                  index === 6 ? "none" : `1px solid ${palette.grey[200]}`,
                borderBottom: `1px solid ${palette.grey[200]}`,
                backgroundColor: "grey.50",
                textAlign: "center",
              }}
            >
              <Typography
                sx={{
                  fontSize: "0.72rem",
                  fontWeight: 700,
                  color: "grey.500",
                  textTransform: "uppercase",
                  letterSpacing: "0.06em",
                }}
              >
                {WEEK_DAYS[date.getDay()]}
              </Typography>

              <Typography
                sx={{
                  fontSize: "0.88rem",
                  fontWeight: 700,
                  color: "text.primary",
                  mt: 0.35,
                }}
              >
                {formatDayLabel(date)}
              </Typography>
            </Box>
          ))}

          {TIME_SLOTS.map((slot) => (
            <React.Fragment key={slot}>
              <Box
                sx={{
                  px: 1.25,
                  py: 1.5,
                  borderRight: `1px solid ${palette.grey[200]}`,
                  borderBottom: `1px solid ${palette.grey[100]}`,
                  backgroundColor: "grey.50",
                }}
              >
                <Typography
                  sx={{
                    fontSize: "0.75rem",
                    fontWeight: 600,
                    color: "grey.500",
                  }}
                >
                  {slot}
                </Typography>
              </Box>

              {weekDates.map((date, index) => {
                const dateKey = date.toISOString().split("T")[0];
                const daySchedules = groupedSchedules[dateKey] || [];

                const matchingSchedules = daySchedules.filter((schedule) => {
                  const scheduleMinutes = parseTimeToMinutes(schedule.time);
                  const slotMinutes = parseTimeToMinutes(slot);
                  return (
                    scheduleMinutes >= slotMinutes &&
                    scheduleMinutes < slotMinutes + 60
                  );
                });

                return (
                  <Box
                    key={`${dateKey}-${slot}`}
                    sx={{
                      minHeight: 140,
                      maxHeight: 140,
                      p: 1,
                      borderRight:
                        index === 6 ? "none" : `1px solid ${palette.grey[100]}`,
                      borderBottom: `1px solid ${palette.grey[100]}`,
                      backgroundColor: "background.paper",
                      overflowY: matchingSchedules.length > 2 ? "auto" : "hidden",
                    }}
                  >
                    <Box sx={{ display: "flex", flexDirection: "column", gap: 0.75 }}>
                      {matchingSchedules.length > 1 && (
                        <Chip
                          label={`${matchingSchedules.length} blocks`}
                          size="small"
                          sx={{
                            alignSelf: "flex-start",
                            height: 22,
                            fontSize: "0.68rem",
                            fontWeight: 700,
                            backgroundColor: "#F2F4F7",
                            color: "grey.600",
                          }}
                        />
                      )}

                      {matchingSchedules.map((schedule) => {
                        const style = statusStyles[schedule.status];

                        return (
                          <Box
                            key={schedule.id}
                            onClick={() => onEventClick?.(schedule)}
                            sx={{
                              p: 1,
                              borderRadius: "10px",
                              backgroundColor: style.bg,
                              border: `1px solid ${style.border}`,
                              cursor: onEventClick ? "pointer" : "default",
                            }}
                          >
                            <Typography
                              sx={{
                                fontSize: "0.72rem",
                                fontWeight: 700,
                                color: style.text,
                                lineHeight: 1.3,
                              }}
                            >
                              {schedule.time} to {schedule.endTime}
                            </Typography>

                            <Typography
                              sx={{
                                fontSize: "0.76rem",
                                fontWeight: 700,
                                color: "text.primary",
                                mt: 0.35,
                                lineHeight: 1.3,
                              }}
                            >
                              {schedule.department}
                            </Typography>

                            <Typography
                              sx={{
                                fontSize: "0.7rem",
                                color: "grey.500",
                                mt: 0.25,
                                lineHeight: 1.3,
                              }}
                            >
                              {schedule.room || "Room TBD"}
                            </Typography>
                          </Box>
                        );
                      })}
                    </Box>
                  </Box>
                );
              })}
            </React.Fragment>
          ))}
        </Box>
      </Box>
    </Card>
  );
}