export { default } from "./DoctorCard";
