export { default } from "./PatientSettingsPage";
