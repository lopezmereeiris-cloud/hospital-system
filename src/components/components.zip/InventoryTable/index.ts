export { default } from "./InventoryTable";
