export { default } from "./PatientRegistrationForm";
