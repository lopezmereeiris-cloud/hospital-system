export { default } from "./BeneficiaryDetailModal";
