export { default } from "./YakapRegistrationForm";
