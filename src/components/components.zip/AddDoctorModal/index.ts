export { default } from "./AddDoctorModal";
