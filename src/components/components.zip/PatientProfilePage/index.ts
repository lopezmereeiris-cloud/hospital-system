export { default } from "./PatientProfilePage";
