// AddMedicineModal interface placeholder
// Add any props/types here if needed in future