export { default } from "./BeneficiaryTable";
