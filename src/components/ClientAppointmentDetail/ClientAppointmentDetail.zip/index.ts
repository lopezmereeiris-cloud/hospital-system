export { default } from "./ClientAppointmentDetail";
